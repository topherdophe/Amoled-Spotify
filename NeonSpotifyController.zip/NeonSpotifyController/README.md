# Neon Spotify Controller — Android source project

A minimal, black (`#000000`) and neon-green (`#00FF00`) Spotify Premium remote controller. No on-screen branding or Android status bar. Displays local time, battery percentage, track/artist, transport controls, Spotify search, and playlists. Screen stays on by default; content shifts by a few pixels each minute to help reduce OLED burn-in risk.

## Build and connect

1. Install Android Studio (with Android SDK 35 and JDK 17). Open this folder as a project and let Gradle sync.
2. Create a Spotify app at https://developer.spotify.com/dashboard and copy its **Client ID**.
3. In `app/src/main/res/values/strings.xml`, replace `REPLACE_WITH_SPOTIFY_CLIENT_ID` with that Client ID.
4. In the Spotify app settings, add **exactly** `neonspotify://callback` as a redirect URI (subject to Spotify's current redirect-URI policy). Add your Spotify account to the app's permitted users if your app is in development mode.
5. Build/install on your Android phone. Tap **CONNECT** and authorize. Open Spotify and start playing on a device, then return to the controller.

This project uses Spotify Web API + Authorization Code with PKCE (no client secret). Playback controls require a Spotify Premium account and an active Spotify Connect device. The Spotify app or another compatible playback device handles the actual audio.

## Notes and limitations

- Spotify developer app permissions, user quotas, endpoint access and redirect URI policies may change. If Spotify does not permit the custom-scheme redirect for your app, the OAuth redirect setup must be adapted to a supported redirect mechanism before login will work.
- Some Spotify Web API endpoints may be restricted for newly created developer apps. A 403 response may mean access restrictions rather than a code bug.
- Search and playlist lists currently show the first 20 tracks / first 50 playlists respectively; pagination can be added.
- A Spotify playback device must already be active; this prototype does not implement device selection or automatic device transfer.
- Green pixel shifting mitigates but does not prevent burn-in. It does not alter the Android system brightness. Brightness controls can be added later.
- This is **source code**, not a compiled APK. It has not been tested on a physical phone or compiled in this environment.
- OAuth tokens are stored in app-private SharedPreferences for this prototype. For production, use Android Keystore-backed encrypted storage and add sign-out/token revocation.
