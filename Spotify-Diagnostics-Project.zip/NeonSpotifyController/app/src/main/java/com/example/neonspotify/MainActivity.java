package com.example.neonspotify;

import android.app.Activity;
import android.os.Bundle;
import android.os.BatteryManager;
import android.content.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Handler;
import android.view.*;
import android.widget.*;
import org.json.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.*;

public class MainActivity extends Activity {
    private static final int GREEN = Color.rgb(0,255,0), BLACK = Color.BLACK;
    private static final String REDIRECT = "neonspotify://callback";
    private static final String SCOPES = "user-read-playback-state user-modify-playback-state user-read-currently-playing playlist-read-private playlist-read-collaborative";
    private final Handler handler = new Handler();
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private LinearLayout root, content, top;
    private TextView clock, battery, title, artist, play, message;
    private boolean keepOn = true, isPlaying = false;
    private String currentUri = "", deviceId = "";
    private long expiresAt = 0;
    private String accessToken = "", refreshToken = "";
    private String lastDiagnostic = "No requests yet";
    private final Runnable tick = new Runnable() {
        public void run() {
            if (clock != null) clock.setText(new SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date()));
            if (battery != null) {
                Intent i = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
                if (i != null) { int level=i.getIntExtra(BatteryManager.EXTRA_LEVEL,-1), scale=i.getIntExtra(BatteryManager.EXTRA_SCALE,100);
                    battery.setText(level >= 0 ? Math.round(level*100f/scale)+"%" : "--%"); }
            }
            // Shift drawn content without changing clickable view bounds.
            if (content != null) {
                long step = System.currentTimeMillis()/60000L;
                float dx = (float)((step % 5)-2)*2f;
                float dy = (float)(((step/5)%5)-2)*2f;
                content.setTranslationX(dp(dx)); content.setTranslationY(dp(dy));
            }
            handler.postDelayed(this, 1000);
        }
    };
    private final Runnable polling = new Runnable() {
        public void run() { if (!accessToken.isEmpty()) refreshPlayback(); handler.postDelayed(this, 6000); }
    };

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().getDecorView().setSystemUiVisibility(5894 | View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
        getWindow().setNavigationBarColor(BLACK); getWindow().setStatusBarColor(BLACK);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        android.content.SharedPreferences p=getPreferences(MODE_PRIVATE);
        accessToken=p.getString("access", ""); refreshToken=p.getString("refresh", ""); expiresAt=p.getLong("expiry",0);
        showPlayer(); handler.post(tick); handler.post(polling);
        handleIntent(getIntent());
    }
    @Override public void onNewIntent(Intent i) { super.onNewIntent(i); setIntent(i); handleIntent(i); }
    @Override protected void onDestroy() { handler.removeCallbacks(tick); handler.removeCallbacks(polling); io.shutdownNow(); super.onDestroy(); }
    private int dp(float d) { return (int)(d*getResources().getDisplayMetrics().density); }
    private TextView text(String s, int size, boolean bold) {
        TextView v=new TextView(this); v.setText(s); v.setTextColor(GREEN); v.setTextSize(size); v.setGravity(Gravity.CENTER);
        if (bold) v.setTypeface(Typeface.DEFAULT,Typeface.BOLD); return v;
    }
    private TextView action(String s, int size, Runnable r) {
        TextView v=text(s,size,false); v.setPadding(dp(12),dp(12),dp(12),dp(12)); v.setOnClickListener(w->r.run()); return v;
    }
    private void base() {
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(BLACK);
        root.setPadding(dp(16),dp(28),dp(16),dp(20)); setContentView(root);
        top=new LinearLayout(this); top.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL); root.addView(top,new LinearLayout.LayoutParams(-1,dp(52)));
        battery=text("--%",17,false); top.addView(battery);
        top.addView(action("ⓘ",24,()->showDiagnostics())); top.addView(action("⌕",36,()->showSearch())); top.addView(action("☷",32,()->showPlaylists()));
        content=new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setGravity(Gravity.CENTER);
        root.addView(content,new LinearLayout.LayoutParams(-1,0,1));
    }
    private void showPlayer() {
        base();
        clock=text("--:--",50,false); content.addView(clock,new LinearLayout.LayoutParams(-1,dp(110)));
        title=text("No track playing",26,true); content.addView(title);
        artist=text("Connect to Spotify",19,false); artist.setAlpha(.75f); content.addView(artist);
        LinearLayout controls=new LinearLayout(this); controls.setGravity(Gravity.CENTER); controls.setPadding(0,dp(36),0,dp(16)); content.addView(controls);
        controls.addView(action("|◀",36,()->command("POST","/me/player/previous",null)));
        play=action(isPlaying?"Ⅱ":"▶",52,()->command("PUT",isPlaying?"/me/player/pause":"/me/player/play",null)); controls.addView(play);
        controls.addView(action("▶|",36,()->command("POST","/me/player/next",null)));
        message=text("",13,false); content.addView(message);
        LinearLayout bottom=new LinearLayout(this); bottom.setGravity(Gravity.CENTER_VERTICAL); root.addView(bottom);
        TextView keep=action("Keep screen on: "+(keepOn?"ON":"OFF"),18,()->{
            keepOn=!keepOn; if(keepOn) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            showPlayer(); });
        bottom.addView(keep,new LinearLayout.LayoutParams(0,dp(64),1));
        if (accessToken.isEmpty()) { TextView login=action("CONNECT",18,this::login); bottom.addView(login); }
        else refreshPlayback();
    }
    private void showSearch() {
        base(); TextView heading=text("Search Spotify",23,true); content.addView(heading);
        EditText query=new EditText(this); query.setSingleLine(true); query.setTextColor(GREEN); query.setHintTextColor(0xff668866);
        query.setHint("Song, artist or album"); content.addView(query);
        ScrollView scroll=new ScrollView(this); content.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout results=new LinearLayout(this); results.setOrientation(LinearLayout.VERTICAL); scroll.addView(results);
        content.addView(action("SEARCH",20,()->{
            if (accessToken.isEmpty()) { login(); return; }
            request("GET","/search?q="+Uri.encode(query.getText().toString())+"&type=track&limit=20",null,(code,body)->{
                results.removeAllViews(); if(code!=200){ status("Search failed: "+code); return; }
                try { JSONArray items=new JSONObject(body).getJSONObject("tracks").getJSONArray("items");
                    for(int j=0;j<items.length();j++){ JSONObject t=items.getJSONObject(j);
                        String name=t.optString("name"), uri=t.optString("uri");
                        String who=t.getJSONArray("artists").getJSONObject(0).optString("name");
                        results.addView(action(name+"\n"+who,17,()->playUri(uri)));
                    }
                }catch(Exception e){status("Unable to read results");}
            });
        }));
        content.addView(action("BACK",17,this::showPlayer));
    }
    private void showPlaylists() {
        base(); content.addView(text("Your playlists",23,true));
        ScrollView scroll=new ScrollView(this); content.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout items=new LinearLayout(this); items.setOrientation(LinearLayout.VERTICAL); scroll.addView(items);
        content.addView(action("BACK",17,this::showPlayer));
        if (accessToken.isEmpty()) { items.addView(action("CONNECT TO SPOTIFY",20,this::login)); return; }
        request("GET","/me/playlists?limit=50",null,(code,body)->{
            if(code!=200){items.addView(text("Playlists failed: HTTP "+code+"\n"+shortError(body),15,false));return;}
            try {JSONArray a=new JSONObject(body).getJSONArray("items");
                for(int j=0;j<a.length();j++){JSONObject p=a.optJSONObject(j);if(p==null)continue;
                    String name=p.optString("name"),uri=p.optString("uri");
                    items.addView(action(name,19,()->playContext(uri)));
                }
            }catch(Exception e){status("Unable to read playlists");}
        });
    }
    private void playUri(String uri){ try {JSONObject json=new JSONObject();json.put("uris",new JSONArray().put(uri));
        command("PUT","/me/player/play",json.toString());showPlayer();}catch(Exception ignored){} }
    private void playContext(String uri){try{JSONObject json=new JSONObject();json.put("context_uri",uri);
        command("PUT","/me/player/play",json.toString());showPlayer();}catch(Exception ignored){} }
    private void command(String method,String path,String data){
        request(method,path,data,(code,body)->{
            if(code==204||code==200||code==202){refreshPlayback();}
            else if(code==404)status("Open Spotify and select a playback device first");
            else if(code==403)status("Spotify 403: "+shortError(body));
            else status("Spotify HTTP "+code+": "+shortError(body));
        });
    }
    private void refreshPlayback(){
        request("GET","/me/player",null,(code,body)->{
            if(code==204)return;
            if(code!=200){status("Playback status HTTP "+code+": "+shortError(body));return;}
            if(body.isEmpty())return;
            try {JSONObject j=new JSONObject(body); isPlaying=j.optBoolean("is_playing");
                JSONObject item=j.optJSONObject("item"); if(item!=null){
                    String name=item.optString("name"),who=item.getJSONArray("artists").getJSONObject(0).optString("name");
                    if(title!=null)title.setText(name);if(artist!=null)artist.setText(who);
                }
                if(play!=null)play.setText(isPlaying?"Ⅱ":"▶");
            }catch(Exception ignored){}
        });
    }
    private interface Callback {void done(int code,String body);}
    private void request(String method,String path,String data,Callback cb){
        io.execute(()->{
            try {
                ensureToken(); if(accessToken.isEmpty()){runOnUiThread(()->status("Connect to Spotify first"));return;}
                URL u=new URL("https://api.spotify.com/v1"+path); HttpURLConnection c=(HttpURLConnection)u.openConnection();
                c.setRequestMethod(method);c.setRequestProperty("Authorization","Bearer "+accessToken);
                c.setConnectTimeout(12000);c.setReadTimeout(12000);
                if(data!=null){c.setDoOutput(true);c.setRequestProperty("Content-Type","application/json");c.getOutputStream().write(data.getBytes(StandardCharsets.UTF_8));}
                int code=c.getResponseCode();InputStream in=code<400?c.getInputStream():c.getErrorStream();
                String body=in==null?"":new String(in.readAllBytes(),StandardCharsets.UTF_8);
                c.disconnect();
                String diagnostic=method+" "+path.split("\\?")[0]+" → HTTP "+code+(code>=400?" : "+shortError(body):"");
                runOnUiThread(()->{lastDiagnostic=diagnostic;cb.done(code,body);});
            }catch(Exception e){runOnUiThread(()->status("Network error: "+e.getMessage()));}
        });
    }
    private void login(){
        String client=getString(R.string.spotify_client_id);
        if(client.startsWith("REPLACE")){status("Set your Spotify Client ID in strings.xml");return;}
        try {
            byte[] bytes=new byte[32];new SecureRandom().nextBytes(bytes);
            String verifier=Base64.getUrlEncoder().withoutPadding().encodeToString(bytes);
            byte[] hash=MessageDigest.getInstance("SHA-256").digest(verifier.getBytes(StandardCharsets.US_ASCII));
            String challenge=Base64.getUrlEncoder().withoutPadding().encodeToString(hash);
            String state=UUID.randomUUID().toString();
            getPreferences(MODE_PRIVATE).edit().putString("verifier",verifier).putString("state",state).apply();
            Uri url=Uri.parse("https://accounts.spotify.com/authorize").buildUpon()
                .appendQueryParameter("response_type","code").appendQueryParameter("client_id",client)
                .appendQueryParameter("redirect_uri",REDIRECT).appendQueryParameter("scope",SCOPES)
                .appendQueryParameter("code_challenge_method","S256").appendQueryParameter("code_challenge",challenge)
                .appendQueryParameter("state",state).build();
            startActivity(new Intent(Intent.ACTION_VIEW,url));
        }catch(Exception e){status("Unable to start login");}
    }
    private void handleIntent(Intent intent){
        Uri uri=intent==null?null:intent.getData();if(uri==null||!"neonspotify".equals(uri.getScheme()))return;
        String code=uri.getQueryParameter("code"),state=uri.getQueryParameter("state");
        if(code==null||!Objects.equals(state,getPreferences(MODE_PRIVATE).getString("state",""))){status("Spotify authorization failed");return;}
        io.execute(()->{
            try {
                String verifier=getPreferences(MODE_PRIVATE).getString("verifier","");
                String body="grant_type=authorization_code&code="+enc(code)+"&redirect_uri="+enc(REDIRECT)+"&client_id="+enc(getString(R.string.spotify_client_id))+"&code_verifier="+enc(verifier);
                JSONObject token=tokenPost(body);saveToken(token);
                runOnUiThread(()->lastDiagnostic="Spotify OAuth token exchange successful");
                runOnUiThread(this::showPlayer);
            }catch(Exception e){runOnUiThread(()->status("Login failed: "+e.getMessage()));}
        });
    }
    private String shortError(String body){
        if(body==null||body.isEmpty())return "No response details";
        try {JSONObject j=new JSONObject(body);JSONObject e=j.optJSONObject("error");
            if(e!=null)return e.optString("message",body);
            return j.optString("error_description",j.optString("error",body));
        }catch(Exception ignored){return body.length()>240?body.substring(0,240):body;}
    }
    private void showDiagnostics(){
        base();content.addView(text("Spotify diagnostics",23,true));
        content.addView(text(accessToken.isEmpty()?"Session: disconnected":"Session: token stored",17,false));
        TextView result=text("Last request:\n"+lastDiagnostic,15,false);result.setPadding(dp(8),dp(24),dp(8),dp(24));content.addView(result);
        content.addView(action("TEST ACCOUNT",18,()->request("GET","/me",null,(code,body)->{
            if(code==200){try{JSONObject j=new JSONObject(body);result.setText("Connected as: "+j.optString("display_name",j.optString("id"))+"\nAccount ID: "+j.optString("id")+"\nProduct: "+j.optString("product","not provided"));}catch(Exception e){result.setText("Account response unreadable");}}
            else result.setText("Account HTTP "+code+"\n"+shortError(body));
        })));
        content.addView(action("DISCONNECT AND REAUTHORISE",17,()->{
            getPreferences(MODE_PRIVATE).edit().remove("access").remove("refresh").remove("expiry").remove("state").remove("verifier").apply();
            accessToken="";refreshToken="";expiresAt=0;isPlaying=false;currentUri="";deviceId="";
            lastDiagnostic="Stored session cleared";login();
        }));
        content.addView(action("BACK",17,this::showPlayer));
    }
    private String enc(String s){return URLEncoder.encode(s,StandardCharsets.UTF_8);}
    private JSONObject tokenPost(String data)throws Exception{
        HttpURLConnection c=(HttpURLConnection)new URL("https://accounts.spotify.com/api/token").openConnection();
        c.setRequestMethod("POST");c.setDoOutput(true);c.setConnectTimeout(12000);c.setReadTimeout(12000);
        c.setRequestProperty("Content-Type","application/x-www-form-urlencoded");
        c.getOutputStream().write(data.getBytes(StandardCharsets.UTF_8));int code=c.getResponseCode();
        InputStream in=code<400?c.getInputStream():c.getErrorStream();String body=new String(in.readAllBytes(),StandardCharsets.UTF_8);c.disconnect();
        if(code!=200)throw new IOException("Token request "+code+": "+body);
        return new JSONObject(body);
    }
    private void saveToken(JSONObject t){
        accessToken=t.optString("access_token",accessToken);refreshToken=t.optString("refresh_token",refreshToken);
        expiresAt=System.currentTimeMillis()+t.optLong("expires_in",3600)*1000L;
        getPreferences(MODE_PRIVATE).edit().putString("access",accessToken).putString("refresh",refreshToken).putLong("expiry",expiresAt).apply();
    }
    private void ensureToken()throws Exception{
        if(System.currentTimeMillis()<expiresAt-60000||refreshToken.isEmpty())return;
        JSONObject t=tokenPost("grant_type=refresh_token&refresh_token="+enc(refreshToken)+"&client_id="+enc(getString(R.string.spotify_client_id)));
        saveToken(t);
    }
    private void status(String s){if(message!=null)message.setText(s);else Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
}
